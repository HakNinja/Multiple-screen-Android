package com.example.dummyapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final String MSG="mykey";

    public void submitTo(View view){
        //intent object
        Intent intent = new Intent(this,welcome.class);
        //edit text
        EditText editText1= findViewById(R.id.editTextTextPersonName);
        //our string
        String mystring="Welcome, "+editText1.getText().toString()+"\n\nMay be you like this application ...";
        //set a string with key-value pair passes to the next windows
        intent.putExtra(MSG,mystring);
        //start intenting
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}