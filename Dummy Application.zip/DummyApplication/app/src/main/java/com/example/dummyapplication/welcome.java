package com.example.dummyapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class welcome extends AppCompatActivity {


    //editing in this default function
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        //my_code
        Intent intent= getIntent();
        //get string from the previous point
        String mystring=intent.getStringExtra(MainActivity.MSG);

        //get Textview
        TextView textView=findViewById(R.id.textView);
        //set value to Textview
        textView.setText(mystring);

    }
}